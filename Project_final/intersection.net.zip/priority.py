import traci
import time
import json

# --- [상수 설정] ---
STOP_LINE = 11.0
STEP_LEN = 0.1
SPAWN_STEP_INTERVAL = 5

active_reservations = {}


def update_status(v_id):
    """차량의 교차로 진입 및 통과 상태를 업데이트하는 함수"""
    if v_id not in active_reservations: return
    info = active_reservations[v_id]
    x, y = traci.vehicle.getPosition(v_id)
    length = info['length']
    entry, target_exit = info['entry'], info['exit']

    if info['status'] == -1:  # 진입 전 -> 교차로 내부
        if (entry == 'N' and y < STOP_LINE) or (entry == 'S' and y > -STOP_LINE) or \
                (entry == 'E' and x < STOP_LINE) or (entry == 'W' and x > -STOP_LINE):
            info['status'] = 0
    elif info['status'] == 0:  # 교차로 내부 -> 통과 완료
        if (target_exit == 'N' and (y - length) > STOP_LINE) or \
                (target_exit == 'S' and (y + length) < -STOP_LINE) or \
                (target_exit == 'E' and (x - length) > STOP_LINE) or \
                (target_exit == 'W' and (x + length) < -STOP_LINE):
            info['status'] = 1


def run_simulation():
    # 1. JSON 데이터 로드
    with open('scenario.json', 'r') as f:
        scenario_data = json.load(f)

    total_to_spawn = len(scenario_data)

    # 2. 기존 설정으로 SUMO 실행
    sumo_cmd = ["sumo-gui", "-c", "intersection.sumocfg"]
    traci.start(sumo_cmd)

    # 3. 시나리오의 경로(Route)를 SUMO에 등록
    # json의 origin_edge와 to_edge를 연결하여 경로 생성
    for v_data in scenario_data:
        try:
            traci.route.add(v_data['route_id'], [v_data['origin_edge'], v_data['to_edge']])
        except traci.exceptions.TraCIException:
            pass  # 이미 등록된 경로는 무시

    veh_count = 0
    step_counter = 0
    start_time = 0.0

    print(f"시나리오 기반 시뮬레이션 시작 (총 {total_to_spawn}대)")

    try:
        # 생성할 차량이 남았거나 도로에 차량이 있는 동안 실행
        while veh_count < total_to_spawn or traci.vehicle.getIDCount() > 0:
            traci.simulationStep()
            current_vehs = traci.vehicle.getIDList()
            current_sim_time = traci.simulation.getTime()

            # --- [차량 생성 로직: JSON 기반] ---
            if step_counter % SPAWN_STEP_INTERVAL == 0 and veh_count < total_to_spawn:
                if veh_count == 0:
                    start_time = current_sim_time

                v_data = scenario_data[veh_count]
                v_id = v_data['veh_id']
                r_id = v_data['route_id']
                l_idx = v_data['lane']
                v_speed = v_data['speed']

                # 에지 이름에서 방향 추출 (e_in -> E)
                start_node = v_data['origin_edge'].split('_')[0].upper()
                end_node = v_data['to_edge'].split('_')[0].upper()

                try:
                    traci.vehicle.add(v_id, r_id, departLane=str(l_idx))
                    traci.vehicle.setLaneChangeMode(v_id, 0)
                    traci.vehicle.setSpeedMode(v_id, 1)  # 안전거리 유지 모드
                    traci.vehicle.setSpeed(v_id, v_speed)

                    # N, S 진입은 우선순위 1(Main), E, W 진입은 -1(Sub)
                    priority = 1 if start_node in ['N', 'S'] else -1

                    active_reservations[v_id] = {
                        'id': v_id, 'priority': priority, 'status': -1,
                        'entry': start_node, 'exit': end_node,
                        'length': traci.vehicle.getLength(v_id), 'orig_speed': v_speed
                    }
                    veh_count += 1
                except Exception as e:
                    print(f"에러 ({v_id}): {e}")

            # --- [우선순위 제어 로직: 기존 main_occupied 방식] ---
            main_occupied = any(v['priority'] == 1 and v['status'] < 1 for v in active_reservations.values())

            for vid in list(active_reservations.keys()):
                if vid in current_vehs:
                    info = active_reservations[vid]
                    x, y = traci.vehicle.getPosition(vid)

                    if info['priority'] == -1:  # 서브 도로 차량 제어
                        if info['status'] == -1:
                            if main_occupied:
                                dist = 0
                                if info['entry'] == 'E':
                                    dist = x - STOP_LINE
                                elif info['entry'] == 'W':
                                    dist = (-STOP_LINE) - x
                                elif info['entry'] == 'N':
                                    dist = y - STOP_LINE
                                elif info['entry'] == 'S':
                                    dist = (-STOP_LINE) - y

                                if dist > 0.01:
                                    calc_speed = max(0.0, dist / STEP_LEN)
                                    traci.vehicle.setSpeed(vid, min(calc_speed, info['orig_speed']))
                                else:
                                    traci.vehicle.setSpeed(vid, 0)
                            else:
                                traci.vehicle.setSpeed(vid, info['orig_speed'])
                        elif info['status'] == 0:
                            traci.vehicle.setSpeed(vid, info['orig_speed'])
                    update_status(vid)
                else:
                    # 퇴거한 차량 정보 삭제
                    if vid in active_reservations and active_reservations[vid]['status'] == 1:
                        del active_reservations[vid]

            step_counter += 1
            time.sleep(0.01)

        # 4. 결과 출력
        end_time = traci.simulation.getTime()
        print(f"\n총 소요 시간: {end_time - start_time:.2f}s")

    finally:
        traci.close()


if __name__ == "__main__":
    run_simulation()