import traci
import time
import json


def run_simulation():
    # 1. JSON 시나리오 데이터 로드
    with open('scenario.json', 'r') as f:
        scenario_data = json.load(f)

    total_to_spawn = len(scenario_data)

    # 2. 시뮬레이션 설정 로드 (신호등 네트워크)
    sumo_cmd = ["sumo-gui", "-c", "signal.sumocfg"]
    traci.start(sumo_cmd)

    # 3. JSON에 있는 경로(Route)들을 SUMO에 등록
    # 기존 BASE_ROUTES 대신 JSON의 에지 정보를 사용하여 실시간 등록
    registered_routes = set()
    for v_info in scenario_data:
        r_id = v_info['route_id']
        if r_id not in registered_routes:
            edges = [v_info['origin_edge'], v_info['to_edge']]
            traci.route.add(r_id, edges)
            registered_routes.add(r_id)

    veh_count = 0
    spawn_interval = 5

    start_sim_time = 0.0
    end_sim_time = 0.0
    is_first_spawn = True

    print(f"시나리오 시뮬레이션 시작: 5스텝 주기 (총 {total_to_spawn}대)")

    try:
        step = 0
        # 모든 차량이 생성되고, 도로 위에 남은 차량이 없을 때까지 루프 진행
        while veh_count < total_to_spawn or traci.vehicle.getIDCount() > 0:
            traci.simulationStep()

            # --- [JSON 기반 자동 생성 로직] ---
            if step % spawn_interval == 0 and veh_count < total_to_spawn:
                # JSON에서 현재 순서의 차량 데이터 추출
                v_data = scenario_data[veh_count]
                veh_id = v_data['veh_id']
                route_id = v_data['route_id']
                target_lane = str(v_data['lane'])  # JSON의 lane 정보 사용
                assigned_speed = v_data['speed']  # JSON의 speed 정보 사용

                try:
                    traci.vehicle.add(veh_id, route_id, departLane=target_lane)
                    traci.vehicle.setLaneChangeMode(veh_id, 0)

                    # 신호등 준수 및 안전거리 유지를 위해 31 설정
                    traci.vehicle.setSpeedMode(veh_id, 31)
                    traci.vehicle.setSpeed(veh_id, assigned_speed)

                    # 첫 번째 차량 생성 시점 기록
                    if is_first_spawn:
                        start_sim_time = traci.simulation.getTime()
                        is_first_spawn = False

                    veh_count += 1
                    if veh_count == total_to_spawn:
                        print("모든 시나리오 차량 생성 완료. 퇴거 대기 중...")

                except Exception as e:
                    print(f"차량 생성 에러 ({veh_id}): {e}")

            step += 1
            time.sleep(0.01)

        # 마지막 차량이 나간 시점 기록
        end_sim_time = traci.simulation.getTime()

        # 결과 출력
        total_duration = end_sim_time - start_sim_time
        print("\n--- 시뮬레이션 결과 ---")
        print(f"첫 차량 생성 시각: {start_sim_time:.2f} s")
        print(f"마지막 차량 퇴거 시각: {end_sim_time:.2f} s")
        print(f"총 소요 시간: {total_duration:.2f} s")
        print("-----------------------")

    finally:
        traci.close()


if __name__ == "__main__":
    run_simulation()