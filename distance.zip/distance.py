import os
import sys
import math
import traci


class ConflictPoint:
    def __init__(self, point_id, x, y):
        self.id = point_id
        self.x, self.y = x, y
        self.ApproachCar = {}
        self.PassedCars = set()
        self.last_exit_time = 0

        self.safety_gap = 1.2
        self.occ_length = 5.0

    def UpdateCar(self, car_id, current_sim_time, orig_speed, remaining_dist):
        if car_id in self.PassedCars:
            return

        route_dist = max(remaining_dist, 0.0)

        if not self.ApproachCar and current_sim_time > self.last_exit_time:
            self.last_exit_time = current_sim_time

        earliest_arrival = current_sim_time + (route_dist / orig_speed)

        if car_id not in self.ApproachCar:
            start_time = max(earliest_arrival, self.last_exit_time + self.safety_gap)
            exit_time = start_time + 1.5

            self.last_exit_time = exit_time
            self.ApproachCar[car_id] = {
                'start': start_time,
                'exit': exit_time,
                'dist': route_dist
            }
        else:
            car_list = list(self.ApproachCar.keys())
            try:
                my_idx = car_list.index(car_id)
            except ValueError:
                return

            if my_idx == 0:
                possible_start = max(earliest_arrival, self.ApproachCar[car_id]['start'])
            else:
                front_car = car_list[my_idx - 1]
                reference_time = self.ApproachCar[front_car]['exit']
                possible_start = max(earliest_arrival, reference_time + self.safety_gap)

            current_start = self.ApproachCar[car_id]['start']

            if abs(possible_start - current_start) > 0.2:
                time_diff = possible_start - current_start
                self.ApproachCar[car_id]['start'] = possible_start
                self.ApproachCar[car_id]['exit'] = possible_start + 1.8

                if time_diff > 0:
                    for i in range(my_idx + 1, len(car_list)):
                        rear_car = car_list[i]
                        self.ApproachCar[rear_car]['start'] += time_diff
                        self.ApproachCar[rear_car]['exit'] += time_diff

                self.last_exit_time = self.ApproachCar[car_list[-1]]['exit']

            self.ApproachCar[car_id]['dist'] = route_dist

    def GetRequiredSpeed(self, car_id, current_time, orig_speed):
        if car_id not in self.ApproachCar: return orig_speed

        car_list = list(self.ApproachCar.keys())
        if car_list and car_list[0] == car_id:
            return orig_speed

        data = self.ApproachCar[car_id]
        time_left = data['start'] - current_time

        if time_left <= 0: return orig_speed

        req_v = data['dist'] / max(time_left, 0.1)
        req_v = max(req_v, orig_speed * 0.3)

        if data['dist'] < 5.0:
            req_v = max(req_v, orig_speed * 0.4)

        return min(orig_speed, max(0.1, req_v))

if 'SUMO_HOME' in os.environ:
    tools = os.path.join(os.environ['SUMO_HOME'], 'tools')
    sys.path.append(tools)
else:
    sys.exit("환경 변수 'SUMO_HOME'을 설정해주세요.")

sumoCmd = ["sumo-gui", "-c", "intersection.sumocfg", "--collision.action", "none", "--step-length", "0.05"]
traci.start(sumoCmd)

routes = {
    "route_N_to_S": ["n_in", "s_out"], "route_S_to_N": ["s_in", "n_out"],
    "route_E_to_W": ["e_in", "w_out"], "route_W_to_E": ["w_in", "e_out"],
    "route_N_to_E": ["n_in", "e_out"], "route_S_to_W": ["s_in", "w_out"],
    "route_E_to_S": ["e_in", "s_out"], "route_W_to_N": ["w_in", "n_out"],
    "route_N_to_W": ["n_in", "w_out"], "route_E_to_N": ["e_in", "n_out"],
    "route_W_to_S": ["w_in", "s_out"], "route_S_to_E": ["s_in", "e_out"]
}

for r_id, edges in routes.items():
    try:
        traci.route.add(r_id, edges)
    except:
        pass

conflict_points = {
    "cp_1": ConflictPoint("cp_1", -5.25, 5.25), "cp_2": ConflictPoint("cp_2", -1.75, 5.25),
    "cp_3": ConflictPoint("cp_3", 1.75, 5.25), "cp_4": ConflictPoint("cp_4", 5.25, 5.25),
    "cp_5": ConflictPoint("cp_5", -5.25, 1.75), "cp_6": ConflictPoint("cp_6", -1.75, 1.75),
    "cp_7": ConflictPoint("cp_7", 0.0, 1.75), "cp_8": ConflictPoint("cp_8", 1.75, 1.75),
    "cp_9": ConflictPoint("cp_9", 5.25, 1.75), "cp_10": ConflictPoint("cp_10", -1.75, 0.0),
    "cp_11": ConflictPoint("cp_11", 1.75, 0.0), "cp_12": ConflictPoint("cp_12", -5.25, -1.75),
    "cp_13": ConflictPoint("cp_13", -1.75, -1.75), "cp_14": ConflictPoint("cp_14", 0.0, -1.75),
    "cp_15": ConflictPoint("cp_15", 1.75, -1.75), "cp_16": ConflictPoint("cp_16", 5.25, -1.75),
    "cp_17": ConflictPoint("cp_17", -5.25, -5.25), "cp_18": ConflictPoint("cp_18", -1.75, -5.25),
    "cp_19": ConflictPoint("cp_19", 1.75, -5.25), "cp_20": ConflictPoint("cp_20", 5.25, -5.25),
    "cp_21": ConflictPoint("cp_21", -11, 5.25), "cp_22": ConflictPoint("cp_22", 5.25, 11),
    "cp_23": ConflictPoint("cp_23", -5.25, -11), "cp_24": ConflictPoint("cp_24", 11, -5.25)
}

route_cp_distances = {
    "route_N_to_S_0": {"cp_1": 94.75, "cp_5": 98.25, "cp_12": 101.75, "cp_17": 105.25},
    "route_N_to_S_1": {"cp_2": 94.75, "cp_6": 98.25, "cp_10": 100.0, "cp_13": 101.75, "cp_18": 105.25},
    "route_S_to_N_0": {"cp_20": 94.75, "cp_16": 98.25, "cp_9": 101.75, "cp_4": 105.25},
    "route_S_to_N_1": {"cp_19": 94.75, "cp_15": 98.25, "cp_11": 100.0, "cp_8": 101.75, "cp_3": 105.25},
    "route_E_to_W_0": {"cp_4": 94.75, "cp_3": 98.25, "cp_2": 101.75, "cp_1": 105.25},
    "route_E_to_W_1": {"cp_9": 94.75, "cp_8": 98.25, "cp_7": 100.0, "cp_6": 101.75, "cp_5": 105.25},
    "route_W_to_E_0": {"cp_17": 94.75, "cp_18": 98.25, "cp_19": 101.75, "cp_20": 105.25},
    "route_W_to_E_1": {"cp_12": 94.75, "cp_13": 98.25, "cp_14": 100.0, "cp_15": 101.75, "cp_16": 105.25},
    "route_N_to_E_1": {"cp_2": 94.75, "cp_7": 98.66, "cp_11": 101.13, "cp_16": 105.04},
    "route_S_to_W_1": {"cp_19": 94.75, "cp_14": 98.66, "cp_10": 101.13, "cp_5": 105.04},
    "route_E_to_S_1": {"cp_9": 94.75, "cp_11": 98.66, "cp_14": 101.13, "cp_18": 105.04},
    "route_W_to_N_1": {"cp_12": 94.75, "cp_10": 98.66, "cp_7": 101.13, "cp_3": 105.04},
    "route_N_to_W_0": {"cp_21": 20.0}, "route_E_to_N_0": {"cp_22": 20.0},
    "route_W_to_S_0": {"cp_23": 20.0}, "route_S_to_E_0": {"cp_24": 20.0}
}

vehicle_original_speeds = {}
initialized_cars = set()
step = 0

while step < 72000:
    traci.simulationStep()
    curr_time = traci.simulation.getTime()

    if step == 0:
        # 경로 지정
        traci.vehicle.add("test_rt_car", "route_N_to_W", departLane="0")
        vehicle_original_speeds["test_rt_car"] = 10.0

    active_cars = traci.vehicle.getIDList()

    for car in active_cars:
        if car not in initialized_cars:
            try:
                traci.vehicle.setLaneChangeMode(car, 0)
                traci.vehicle.setSpeedMode(car, 0)
                initialized_cars.add(car)
            except:
                continue

        try:
            orig_v = vehicle_original_speeds.get(car, 10.0)
            rid = traci.vehicle.getRouteID(car)
            lidx = traci.vehicle.getLaneIndex(car)
            key = f"{rid}_{lidx}"

            target_cps_dict = route_cp_distances.get(key, {})

            # 현재 좌표 확인
            x, y = traci.vehicle.getPosition(car)
            current_driven_dist = traci.vehicle.getDistance(car)
            veh_length = traci.vehicle.getLength(car)

            # print(f"차량 ID: {car} | 길이: {veh_length}m")

            # 로그 출력
            if car == "test_rt_car":
                print(f"[Time: {curr_time:.2f}s] | ({x:.2f}, {y:.2f}) | {current_driven_dist:.2f}m")

            final_v = orig_v

            for cp_id, cp_absolute_dist in target_cps_dict.items():
                if cp_id in conflict_points:
                    cp = conflict_points[cp_id]

                    remaining_dist = cp_absolute_dist - current_driven_dist - veh_length

                    if remaining_dist < -3.0:
                        if car not in cp.PassedCars:
                            cp.PassedCars.add(car)
                            if car in cp.ApproachCar:
                                del cp.ApproachCar[car]
                                if not cp.ApproachCar:
                                    cp.last_exit_time = curr_time
                        continue

                    cp.UpdateCar(car, curr_time, orig_v, remaining_dist)

                    if car not in cp.PassedCars:
                        req_v = cp.GetRequiredSpeed(car, curr_time, orig_v)
                        if req_v < final_v:
                            final_v = req_v

            leader = traci.vehicle.getLeader(car, 15.0)
            if leader:
                l_id, l_dist = leader
                l_speed = traci.vehicle.getSpeed(l_id)
                if l_dist < 5.0:
                    final_v = min(final_v, l_speed * 0.85)
                    if l_dist < 2.0: final_v = 0.1
                elif final_v > l_speed:
                    final_v = min(final_v, l_speed + 1.0)

            traci.vehicle.setSpeed(car, final_v)
        except:
            pass

    for car in list(vehicle_original_speeds.keys()):
        if car not in active_cars and traci.simulation.getTime() > 1.0:
            pass

    step += 1

traci.close()