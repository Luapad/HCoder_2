import os
import runpy
import traci
import xml.etree.ElementTree as ET

original_start = traci.start

def modified_start(cmd, *args, **kwargs):
    cmd_list = list(cmd)
    if "--emission-output" not in cmd_list:
        cmd_list.extend(["--emission-output", "fuel_output.xml"])
    return original_start(cmd_list, *args, **kwargs)


traci.start = modified_start

def calculate_fuel(target_veh_id=None):
    if not os.path.exists("fuel_output.xml"):
        print("연료 출력 파일(fuel_output.xml)을 찾을 수 없습니다.")
        return

    if target_veh_id:
        print(f"\n 특정 차량 ['{target_veh_id}']의 연료 소모량 계산 중")
    else:
        print("\n전체 차량의 총 연료 소모량 계산 중")

    tree = ET.parse("fuel_output.xml")
    root = tree.getroot()

    total_fuel_mg = 0.0
    step_length = 0.01
    found_vehicle = False

    for timestep in root.findall('timestep'):
        for vehicle in timestep.findall('vehicle'):
            vid = vehicle.get('id')

            if target_veh_id and vid != target_veh_id:
                continue

            if target_veh_id and vid == target_veh_id:
                found_vehicle = True

            fuel_rate = float(vehicle.get('CO2', 0))  # fuel_output.xml 에서 갖고 오고 싶은 값 적으면 됨.
            total_fuel_mg += fuel_rate * step_length

    if target_veh_id and not found_vehicle:
        print(f"XML 파일에서 '{target_veh_id}' 차량을 찾을 수 없습니다. 아이디를 확인해주세요.")
        return

    total_fuel_g = total_fuel_mg / 1000.0
    total_fuel_ml = total_fuel_g / 0.75

    target_name = f"차량 '{target_veh_id}'" if target_veh_id else "전체 차량"

    print(f"{target_name} 연료 소모량: 약 {total_fuel_g:.4f} g")
    print(f"부피 환산(휘발유)   : 약 {total_fuel_ml:.4f} mL")


if __name__ == "__main__":
    target_file = "FIFO.py"  # 실행할 원본 파일명

    # 추적하고 싶은 차량 ID
    # 전체 차량을 보고 싶다면 None 으로 변경 (TARGET_VEHICLE_ID = None)
    TARGET_VEHICLE_ID = None

    if not os.path.exists(target_file):
        print(f"'{target_file}' 파일이 같은 폴더에 없습니다. 파일명을 확인해주세요.")
    else:
        if TARGET_VEHICLE_ID:
            print(f"\n특정 차량 '{TARGET_VEHICLE_ID}'의 연료 소모량만 추적.")
        else:
            print("\n전체 차량의 연료 소모량을 추적.")

        print(f"'{target_file}' 실행 시작")

        try:
            runpy.run_path(target_file, run_name="__main__")
        except Exception as e:
            print(f"\n실행 중 에러 발생: {e}")
        finally:
            calculate_fuel(target_veh_id=TARGET_VEHICLE_ID)